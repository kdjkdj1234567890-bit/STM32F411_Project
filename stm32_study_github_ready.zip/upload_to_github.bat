@echo off
chcp 65001 > nul
echo ========================================================
echo   GitHub 자동 업로드 스크립트 (STM32 학습 정리)
echo ========================================================
echo.

where git > nul 2>&1
if %errorlevel% neq 0 (
    echo [오류] Git이 설치되어 있지 않습니다. GitHub 웹사이트에서 드래그 앤 드롭으로 업로드해 주세요.
    pause
    exit /b 1
)

if not exist ".git" (
    git init
    git branch -M main
)

set /p REPO_URL="업로드할 본인 GitHub 저장소 주소(예: https://github.com/아이디/저장소명.git)를 입력 후 Enter: "
if "%REPO_URL%"=="" (
    echo [취소] 저장소 주소가 입력되지 않았습니다.
    pause
    exit /b 1
)

git remote remove origin > nul 2>&1
git remote add origin %REPO_URL%

git add README.md "2026-11-18_F411_TASK_LAB_STEP01-03.md" "2026-11-18_학습정리.md" images/
git commit -m "docs: 2026-11-18 STM32 F411_TASK_LAB(STEP01-03) 및 수업 학습 정리 추가"
git push -u origin main

echo.
echo [완료] GitHub 업로드를 마쳤습니다!
pause
